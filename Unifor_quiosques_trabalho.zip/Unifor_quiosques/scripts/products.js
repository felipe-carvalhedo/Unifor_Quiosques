document.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("searchButton");
    if (searchButton) {
        searchButton.addEventListener("click", buscarLoja);
    }

    var produtosEscolhidosString = localStorage.getItem("produtosEscolhidos");
    var produtosEscolhidos = JSON.parse(produtosEscolhidosString);
    if (produtosEscolhidos && produtosEscolhidos.length > 0) {
        var productList = document.querySelector(".product-list");
        produtosEscolhidos.forEach(function (produto) {
            var listItem = document.createElement("li");
            listItem.className = "product-item";
            var img = document.createElement("img");
            img.src = produto.imagem;
            img.alt = produto.nome;
            img.width = 100;
            img.height = 70;
            var productInfo = document.createElement("div");
            productInfo.className = "product-info";
            var productName = document.createElement("span");
            productName.className = "product-name";
            productName.textContent = produto.nome;
            productInfo.appendChild(productName);
            listItem.appendChild(img);
            listItem.appendChild(productInfo);

            if (productList) {
                productList.appendChild(listItem);
            }
        });
    } else {
        console.log("Nenhum produto escolhido");
    }
});

function exibirComentarios() {
    const lojaatual = localStorage.getItem("produtosEscolhidos")
    var produtosEscolhidos = JSON.parse(lojaatual);
    var primeiraLoja = produtosEscolhidos[0].loja;
    var comentariosString = localStorage.getItem("comentarios"+"-"+primeiraLoja);
    var comentarios = JSON.parse(comentariosString);

    if (comentarios && comentarios.length > 0) {
        var commentList = document.getElementById("comment-list");
        commentList.innerHTML = ""; // Limpa os comentários antigos
        comentarios.forEach(function (comentario) {
            var li = document.createElement("li");
            li.className = "comment-item";
            li.appendChild(document.createTextNode(comentario));
            commentList.appendChild(li);
        });
    }
}

function adicionarComentario() {
    var comentario = document.getElementById("comment").value;
    const lojaatual = localStorage.getItem("produtosEscolhidos")
    var produtosEscolhidos = JSON.parse(lojaatual);
    var primeiraLoja = produtosEscolhidos[0].loja;
    console.log(primeiraLoja)
    if (comentario.trim() !== "") {
        var comentariosString = localStorage.getItem("comentarios"+"-"+primeiraLoja);
        var comentarios = comentariosString ? JSON.parse(comentariosString) : [];
        comentarios.push(comentario);
        localStorage.setItem("comentarios"+"-"+primeiraLoja, JSON.stringify(comentarios));
        exibirComentarios();
        document.getElementById("comment").value = "";
    }
}

var arrayDeProdutosCasa = [
  {loja: "casaPao", nome: 'CASA DO PÃO DE QUEIJO PRODUTOS:', valor: "R$2/unidade", imagem: "/images/casa_pao/casa_do_pao_de_queijo_logo.jpeg" },
  { nome: 'Pao de queijo (R$2/unidade)', valor: "R$2/unidade", imagem: "/images/casa_pao/pao-de-queijo_receita.jpg" },
  { nome: 'Panini (R$8/unidade)', valor: "R$2/unidade", imagem: "/images/casa_pao/panini.jpeg" },
  { nome: 'Cafe (R$4/50mL)', valor: "R$2/unidade", imagem: "/images/casa_pao/cafe.jpeg" },
  { nome: 'Suco de limao (R$8/300mL)', valor: "R$2/unidade", imagem: "/images/casa_pao/suco_de_limao.jpg" },
  { nome: 'Bolo (R$8/pedaço)', valor: "R$2/unidade", imagem: "/images/casa_pao/bolo.jpeg" },
];

var arrayDeProdutosKalzone = [
  {loja: "kalzone", nome: 'MINI KALZONE PRODUTOS:', valor: "R$2/unidade", imagem: "/images/mini_kalzone/kalzone.png"},
  { nome: 'Kalzone salgado (R$12/unidade)', valor: "R$10/unidade", imagem: "/images/mini_kalzone/mini_max.jpeg" },
  { nome: 'Smoothies (R$10/300mL)', valor: "R$10/unidade", imagem: "/images/mini_kalzone/smoothie.png" },
  { nome: 'Kalzone doce (R$8/unidade)', valor: "R$10/unidade", imagem: "/images/mini_kalzone/nutella.jpg" },
  { nome: 'Combo (R$35)', valor: "R$10/unidade", imagem: "/images/mini_kalzone/combo.jpg" },
];

var arrayDeProdutosFarmacia = [
  {loja: "farmacia", nome: 'FARMÁCIA SANTA CECÍLIA PRODUTOS:', imagem: "/images/farmacia_cecilia/farmacia_santa_cecilia.jpeg"},
  { nome: 'Água mineral (R$5/unidade)', valor: "R$10/unidade", imagem: "/images/farmacia_cecilia/Agua-Mineral-Garrafinha-500ml.jpg" },
  { nome: 'Nescau (R$5/unidade)', valor: "R$10/unidade", imagem: "/images/farmacia_cecilia/nescau.webp" },
  { nome: 'Pastilha (R$2/unidade)', imagem: "/images/farmacia_cecilia/pastilha.png" },
  { nome: 'Sorvete (R$20/unidade)', imagem: "/images/farmacia_cecilia/sorvete.webp" },
  { nome: 'Medicamentos (Verificar com o atendente)', imagem: "/images/farmacia_cecilia/medicamentos.jpeg" },
];

var arrayDeProdutosTop = [
  {loja: "top", nome: 'TOP LANCHES PRODUTOS:', imagem: "/images/tops/tops_lanches.jpeg"},
  { nome: 'Coxinha (R$8)', valor: "R$10/unidade", imagem: "/images/tops/coxinha.jpg"},
  { nome: 'Sanduíche de frango (R$13)', valor: "R$10/unidade", imagem: "/images/tops/sanduba1.jpeg"},
  { nome: 'Sanduíche de carne (R$13)', valor: "R$10/unidade", imagem: "/images/tops/sanduba2.jpg"},
  { nome: 'Suco de laranja (R$5/300mL)', valor: "R$10/unidade", imagem: "/images/tops/suco_laranja.png"},
  { nome: 'Coca-cola (R$5/lata)', valor: "R$10/unidade", imagem: "/images/tops/coca.webp"},
];

var arrayDeProdutosFrutzen = [
  {loja: "frutzen", nome: 'Frutzen PRODUTOS:', imagem: "/images/frutzen/frutzen.jpeg"},
  { nome: 'Açaí (R$20/300mL)', valor: "R$10/unidade", imagem: "/images/frutzen/acai.jpg" },
  { nome: 'Bola de sorvete com 1 fruta (R$13)', valor: "R$10/unidade", imagem: "/images/frutzen/sorvete.jpg" },
  { nome: 'Salada de frutas (R$15)', valor: "R$10/unidade", imagem: "/images/frutzen/salada_de_frutas.jpg" },
  { nome: 'Suco verde (R$12/300mL)', valor: "R$10/unidade", imagem: "/images/frutzen/suco_verde.jpg" },
  { nome: 'Salgado fit (R$14)', valor: "R$10/unidade", imagem: "/images/frutzen/salgado_fit.jpg" },

];

var arrayDeProdutosCafe = [
  {loja: "cafe", nome: 'CAFÉ DAS ARTES PRODUTOS:', imagem: "/images/cafe_das_artes/cafe_das_Artes.jpg"},
  { nome: 'Café expresso (R$6)', valor: "R$10/unidade", imagem: "/images/cafe_das_artes/cafezinho.jpg" },
  { nome: 'Bolo de chocolate (R$10/pedaço)', valor: "R$10/unidade", imagem: "/images/cafe_das_artes/bolo_chocolate.jpg" },
  { nome: 'Frapê (R$18/pedaço)', valor: "R$10/unidade", imagem: "/images/cafe_das_artes/frape.jpg" },
  { nome: 'Salada carpaccio (R$35/pedaço)', valor: "R$10/unidade", imagem: "/images/cafe_das_artes/salada_carpaccio.jpg" },
  { nome: 'Brigadeiro (R$6/unidade)', valor: "R$10/unidade", imagem: "/images/cafe_das_artes/brigadeiro.jpg" },
];

var arrayDeLojas = [
  { nome: 'Casa do pao de queijo'},
  { nome: 'Mini Kalzone'},
  { nome: 'Farmácia Santa Cecília'},
  { nome: 'Top Lanches'},
  { nome: 'Frutzen'},
  { nome: 'Café das Artes'},
];

function escolherLoja(parametro) {
  switch (parametro) {
    case "1":
      const item1 = JSON.stringify(arrayDeProdutosCasa);
      localStorage.setItem("produtosEscolhidos", item1);
      window.location.href = '/Unifor_quiosques/htmls/products.html';
      break;

    case "2":
      const item2 = JSON.stringify(arrayDeProdutosKalzone);
      localStorage.setItem("produtosEscolhidos", item2);
      window.location.href = '/Unifor_quiosques/htmls/products.html';
      break;

    case "3":
      const item3 = JSON.stringify(arrayDeProdutosFarmacia);
      localStorage.setItem("produtosEscolhidos", item3);
      window.location.href = '/Unifor_quiosques/htmls/products.html';
      break;

    case "4":
      const item4 = JSON.stringify(arrayDeProdutosTop);
      localStorage.setItem("produtosEscolhidos", item4);
      window.location.href = '/Unifor_quiosques/htmls/products.html';
      break;

    case "5":
      const item5 = JSON.stringify(arrayDeProdutosFrutzen);
      localStorage.setItem("produtosEscolhidos", item5);
      window.location.href = '/Unifor_quiosques/htmls/products.html';
      break;

    case "6":
      const item6 = JSON.stringify(arrayDeProdutosCafe);
      localStorage.setItem("produtosEscolhidos", item6);
      window.location.href = '/Unifor_quiosques/htmls/products.html';
      break;

  }
}

var linkClicavel = document.getElementById('linkClicavel');
linkClicavel.addEventListener('click', function() {
  var produtosEscolhidos = localStorage.getItem("produtosEscolhidos");
  if (produtosEscolhidos) {
    console.log("Redirecionando para a página de produtos");
    window.location.href = '/Unifor_quiosques/htmls/products.html';
  } else {
    console.log("Nenhum produto escolhido");
  }
});

function buscarLoja() {
    var busca = document.getElementById("searchInput").value.toLowerCase();

    console.log(busca)
    for (var i = 0; i < arrayDeLojas.length; i++) {
        var nomeDaLoja = arrayDeLojas[i].nome.toLowerCase();
        if (nomeDaLoja.includes(busca)) {
            escolherLoja(i + 1);
            return ;
        }
    }}
